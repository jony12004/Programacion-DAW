
import java.util.Scanner;

public class Partida {
    private Baraja baraja = new Baraja();
    private Jugador jugador;
    private Jugador crupier;
    private Scanner consola = new Scanner(System.in);

    public void IniciarJuego() {
        boolean salir = false;
        
        baraja.mezclar();
        asignarNombre();
        do {
            limpiarManoAmbos();
            apostar();
            obtenerManoAmbos();
            calcularGanador();
            salir = true;
        } while (!salir);
    }

    public void mostrarManoYPuntuacion(Jugador jug) {
        System.out.print(jug.getMano() + " ");
        System.out.print(jug.getPuntuacion() + " puntos");
        System.out.println();
    }

    public void calcularGanador() {
        int contador = 1;
        System.out.println("RONDA " + contador);
        contador++;
        boolean sal = false;
        while(!sal) {
            if(!menor21(jugador)){
                sal = true;
            }
            mostrarManoYPuntuacion(jugador);
            System.out.print("Quieres carta " + jugador.getNombre() + "?(s/n): " );
            char robar = consola.next().toLowerCase().charAt(0);
            if(robar == 's') {
                jugador.robarCarta(baraja);
            }else {
                sal = true;
            }
        }
        do {
            mostrarManoYPuntuacion(crupier); 
            System.out.print("Quieres carta " + crupier.getNombre() + "?(s/n): " );
            char robar = consola.next().toLowerCase().charAt(0);
            if(robar == 's' && (menor21(crupier))) {
                crupier.robarCarta(baraja);
            }else {
                sal = true;
            }
        } while (!sal);
    }

    public void limpiarManoAmbos() {
        jugador.limpiarMano();
        crupier.limpiarMano();
    }
    public void apostar() {
        int apuesta = 0;
        int apuestaCrupier = 0;
        boolean salirJugador = false;
        boolean salirCrupier = false;
        while(!salirJugador) {
            System.out.println("Fondos de " + jugador.getNombre() + ": " + jugador.getFondos());
            System.out.print("Cuanto quieres apostar "+ jugador.getNombre() + ": ");
            apuesta = consola.nextInt();
            if(jugador.getFondos() < apuesta) {
                System.out.println("No tiene suficientes fondos");
            } else {
                salirJugador = true;
            }

        }
        while(!salirCrupier) {
            System.out.println("Fondos de " + crupier.getNombre() + ": " + crupier.getFondos());
            System.out.print("Cuanto quieres apostar "+ crupier.getNombre() + ": ");
            apuestaCrupier = consola.nextInt();
            if(crupier.getFondos() < apuestaCrupier) {
                System.out.println("No tiene suficientes fondos");                
            } else {
                salirCrupier = true;
            }
        }
    }

    public void obtenerManoAmbos() {
        jugador.obtenerMano(baraja);
        crupier.obtenerMano(baraja);
    }
    public void asignarNombre(){
        System.out.print("Introduce un nombre: ");
        String nombre = consola.nextLine();
        jugador = new Jugador(nombre);
        System.out.print("Introduce un nombre para el crupier: ");
        String nombreCrupier = consola.nextLine();
        crupier = new Jugador(nombreCrupier);
    }


    public boolean menor21(Jugador jug) {
        jug.getPuntuacion();
        if(jug.getPuntuacion()<21){
            return true;
        }
        return false;
    }




    
}
