public class App {
    public static void main(String[] args) {
        Partida part = new Partida();
        part.IniciarJuego();
    }
    
}
